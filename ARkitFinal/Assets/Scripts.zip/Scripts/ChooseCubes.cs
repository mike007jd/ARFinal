﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseCubes : MonoBehaviour {

	public GameObject statue1;
	public GameObject statue2;
	public GameObject statue3;
	public GameObject statue4;
	public GameObject masterStatue;
	public GameObject tuna;
	public GameObject ghost;
	public GameObject locker;
	public GameObject parsnip;
	public GameObject egg;
	public GameObject spider;
	public GameObject rice;
	public GameObject peanutButter;
	public GameObject chest;





	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	public void Statue1() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue4.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
	}

	public void Statue2() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue4.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
	}
	public void Statue3() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		statue4.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
	}

	public void Statue4() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue4.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
	}
	public void MasterStatue() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue4.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
	}
	public void Chest() {
		statue1.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue2.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		statue3.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		masterStatue.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = false;
		tuna.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		ghost.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		locker.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		parsnip.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		egg.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		spider.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		rice.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		peanutButter.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
		chest.GetComponent<UnityEngine.XR.iOS.UnityARHitTestExample> ().enabled = true;
	}


}
